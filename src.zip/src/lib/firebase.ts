// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDJzZe_2ozJ3xLcXgiGNTJfjInr2DDiBsc",
  authDomain: "tienda-productos-aura-esencia.firebaseapp.com",
  projectId: "tienda-productos-aura-esencia",
  storageBucket: "tienda-productos-aura-esencia.firebasestorage.app",
  messagingSenderId: "591466725758",
  appId: "1:591466725758:web:7e49cece777946dd52b32f",
  measurementId: "G-HFX85DV4LQ"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);